script.pulsar.newpct
====================
Provaider para la pagina Newpct. Spanish only
Update pulsar 0.3
