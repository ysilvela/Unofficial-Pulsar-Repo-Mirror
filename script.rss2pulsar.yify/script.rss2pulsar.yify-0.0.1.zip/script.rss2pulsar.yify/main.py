# coding: utf-8
import re
import rss

# this read the settings
settings = rss.Settings()
# define the browser
browser = rss.Browser()

url_search = "https://yts.re/rss/0/720p/All/0"
listing = []
ID = []  # IMDB_ID or thetvdb ID
if browser.open(url_search):
    data = browser.content.replace('<title>YTS RSS</title>', '')
    infohash = re.findall('https://yts.re/download/start/(.*?).torrent',data)
    title = re.findall('<title>(.*?)</title>', data)
# else:
#     provider.log.error('>>>>>>>%s<<<<<<<' % browser.status)
#     provider.notify(message=browser.status, header=None, time=5000, image=settings.icon)
#     results = []
rss.integration(title, infohash,'MOVIE', settings.movie_folder, message='YIFY')