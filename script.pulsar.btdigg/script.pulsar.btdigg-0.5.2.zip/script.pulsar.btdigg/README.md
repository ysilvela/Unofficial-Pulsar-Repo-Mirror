script.pulsar.btdigg
====================

Script for pulsar multi language  Kodi / xbmc use API access very fast

Update for Pulsar 0.3

Este script sirve tanto para buscar contenido en español como en otros idiomas con un acceso via API bastante mas rapido he limpiado y optimizado el codigo 
