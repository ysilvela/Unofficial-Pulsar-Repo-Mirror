Introduction
===================
H33t.to pulsar 0.2 provider, using settings
